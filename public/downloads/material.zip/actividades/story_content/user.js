function ExecuteScript(strId)
{
  switch (strId)
  {
      case "64UAd0ahBVN":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

